# YODA + Drifting 适配实现

本目录在官方 `upstream/YODA-main` 与 `upstream/drifting-main` 源码之外提供了一层不改动上游代码的 PyTorch 适配实现。目标是将 YODA 单步 SANA DiT + LoRA 去噪步骤替换为 Drifting 的单次前向漂移生成器。

详细设计、论文差异、验收标准和实测记录见 [docs/PLAN.md](docs/PLAN.md)。

## 已实现

- `yoda_drift/drift_loss.py`：Drifting 多温度漂移目标的 PyTorch 移植。
- `yoda_drift/memory_bank.py`：正样本和生成历史负样本的环形 memory bank。
- `yoda_drift/drift_model.py`：接收 `lq_latent_hat` 和 TA-AE 多尺度上下文的单次前向生成器。
- `yoda_drift/trainer.py`：漂移损失加条件重建辅助损失的训练步。
- `yoda_drift/yoda_hybrid.py`：保留 YODA 编解码接口，并支持 `drift` / `original` 两种 denoiser。
- `scripts/train_drift_smoke.py`：合成小样本训练和预览输出。

## 验证

```powershell
D:\Users\YongZhao\anaconda3\envs\pytorch\python.exe -m unittest discover -s tests -v
```

```powershell
D:\Users\YongZhao\anaconda3\envs\pytorch\python.exe scripts\train_drift_smoke.py --steps 100 --batch-size 4 --frames 8 --latent-size 8 --latent-channels 4 --context-channels 8 4 --hidden-channels 16 --depth 1 --device cpu
```

默认结果写入 `outputs/drift_smoke/`：

- `metrics.json`：训练配置、loss 历史和收敛摘要。
- `latent_preview.png`：生成潜变量与目标的对照图。
- `generator.pt`：smoke 训练得到的生成器权重。

该 smoke 验证单次 NFE、上下文条件、memory bank 更新、漂移梯度和 loss 下降，不代表论文指标。

## 使用替换分支

提供 SANA 模型目录、YODA checkpoint 以及完整上游依赖后可构建：

```python
from yoda_drift.yoda_hybrid import YodaHybridCodec

model = YodaHybridCodec.from_pretrained(
    sd_path="checkpoints/sana-sprint",
    checkpoint_path="checkpoints/yoda_video.pth",
    denoiser="drift",
    upstream_root="upstream/YODA-main",
    device="cuda",
)
```

`denoiser="drift"` 不要求 prompt embedding。使用原始 SANA + LoRA 分支时改为 `denoiser="original"`，并传入 `prompt_embeds_path` 与 `prompt_attention_mask_path`。

## 当前限制

- 本地没有 YODA/SANA checkpoint，不能声称完成论文级指标复现。
- 官方 Drifting 使用 JAX/Flax，本实现是数学等价移植，并通过 PyTorch 接口接入 YODA。
- 真实码流测试还需要 `diffusers`、`peft` 和 `MLCodec_extensions_cpp`。
- 当前 PyTorch 构建不支持 RTX 5060 Laptop 的 `sm_120`，本轮验证在 CPU 上完成。
- 真实数据训练前，需要用 YODA 的 TA-AE/CLC 从视频子集生成潜变量与上下文；当前 smoke 使用合成数据替代此步骤。
