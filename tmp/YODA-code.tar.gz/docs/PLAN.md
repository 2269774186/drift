# YODA + Drifting 复现与替换计划

## 1. 目标

基于本地 `upstream/YODA-main` 与 `upstream/drifting-main` 源码，完成以下工作：

1. 复现 YODA 的核心推理/压缩路径，并在小规模合成视频上跑通。
2. 将 YODA 中“一步 SANA DiT + LoRA 去噪器”替换为 Drifting 论文的一步漂移生成器。
3. 保持 TA-AE、CLC、量化/熵编码接口和帧间上下文路径可复用。
4. 给出可执行的训练、测试、指标与风险说明。

本地公开的 YODA 仓库只包含推理、码流和评估代码，不包含训练代码；Drifting 官方代码为 JAX/Flax，而 YODA 为 PyTorch。因此本计划采用“论文数学等价移植 + YODA 条件适配”的方式，而不是跨框架直接调用。

## 2. 论文与代码差异

### YODA

- TA-AE 从参考帧提取多尺度上下文，并对当前帧编码为 32 通道、1/32 空间分辨率的潜变量。
- CLC 对潜变量做条件熵编码，输出 `lq_latent_hat`。
- SANA-Sprint DiT 接收 `lq_latent_hat` 和提示词条件，注入 LoRA，单步去噪，再由 TA-AE 解码。
- 公开源码没有端到端训练代码，也没有随附 checkpoint。

### Drifting

- 生成器 `f_theta(epsilon)` 单次前向完成生成，推理为 1 NFE。
- 训练不依赖逐步扩散采样；对真实正样本和当前生成/历史负样本计算多温度核漂移场。
- 核函数为 `k(x,y)=exp(-||x-y||/tau)`，使用正负核注意力构造目标漂移，再以 stop-gradient 目标做 MSE。
- 官方实现为 ImageNet 类别条件 JAX/Flax 生成器，使用 memory bank 和 MAE 特征空间。

### 替换关系

| YODA 原实现 | 本实现 |
| --- | --- |
| SANA DiT + LoRA | `ConditionalDriftGenerator` |
| `DiT(lq_latent_hat, prompt, ctxs)` | `G_phi(lq_latent_hat, ctxs, noise)` |
| 单步调度器/SCM 去噪 | 条件漂移生成器单次前向 |
| DiT 训练损失（公开源码未提供） | 漂移损失 + 条件重建辅助损失 |

YODA 的条件输入是压缩潜变量和 TA-AE 多尺度上下文，而 Drifting 原论文是类别条件生成；因此“压缩条件化的 Drifting”是本研究任务的适配扩展，需单独做消融，不能宣称已严格复现论文中的 YODA 训练配方。

## 3. 实现结构

```text
yoda_drift/
├── drift_loss.py          # PyTorch 多温度核漂移损失
├── memory_bank.py         # 按上下文/类别分桶的 ring buffer
├── drift_model.py         # 条件一步漂移生成器
├── trainer.py             # 条件漂移训练步
└── yoda_hybrid.py         # TA-AE + CLC + 可切换 denoiser 装配
scripts/
└── train_drift_smoke.py   # 合成序列/潜变量 smoke 训练
tests/
├── test_drift_loss.py
├── test_memory_bank.py
├── test_drift_model.py
├── test_trainer.py
└── test_hybrid_interface.py
```

接口约定：

```python
denoised = denoiser(lq_latent_hat, ctxs, noise=noise)
```

其中 `lq_latent_hat` 为 `[B, 32, H/32, W/32]`，`ctxs` 为 TA-AE 多尺度特征列表；原始 DiT 分支保留 `denoiser=original`，新分支使用 `denoiser=drift`。

## 4. 漂移训练设计

### 样本

- 正样本：当前帧真实 TA-AE 潜变量 `lq_latent`。
- 条件：量化潜变量 `lq_latent_hat` 与参考帧多尺度上下文 `ctxs`。
- 负样本：历史生成器输出，从 ring buffer 按条件桶采样。

### 目标

对生成样本 `gen`、正样本 `fixed_pos`、负样本 `fixed_neg` 执行：

1. 计算正负样本到生成样本的距离。
2. 用多温度 `R_list=(0.2, 0.05, 0.02)` 计算核注意力。
3. 正样本产生吸引，负样本产生排斥，构造漂移目标。
4. 对目标做 stop-gradient，最小化生成样本到目标的 MSE。

为稳定 YODA 适配，额外加入小权重条件重建 MSE；主损失仍必须包含漂移项。具体权重通过 smoke 消融确定，默认只报告配置，不把辅助损失伪装成论文原损失。

### memory bank

- 正样本按条件桶保存真实潜变量。
- 负样本保存生成器历史输出。
- 使用环形覆盖，支持 CPU 存储和按需搬到计算设备，避免 8 GB 显存上保存大规模历史张量。

## 5. 小样本实验

### 阶段 A：算法单测

- 漂移损失输出形状、有限值和梯度。
- 生成器单次前向、无 LoRA、无迭代采样。
- memory bank 覆盖、采样和空桶行为。
- YODA 条件接口和潜变量形状回归。

### 阶段 B：合成视频 smoke

- 使用低分辨率合成运动序列，例如 128x128、8-16 帧。
- 训练 50-200 步，记录 train loss、条件 MSE、漂移项、总耗时和 CUDA 峰值显存（可用时）。
- 固定随机种子保存重建帧、潜变量误差和指标 JSON。
- 结果只作为“可运行性/收敛性 smoke”，不作为论文指标。

### 阶段 C：真实小数据子集

- 有 YODA/SANA 权重后，使用 1-2 个短视频序列或 Vimeo-90K 小子集。
- 先冻结 TA-AE/CLC，仅训练漂移分支；再视显存解冻少量层。
- 评估 PSNR、MS-SSIM、LPIPS、DISTS、bpp、编码/解码时间和峰值显存。

## 6. 验收标准

必须满足：

1. `drift_loss` 与官方实现公式逐项对应，并有梯度测试。
2. `denoiser=original|drift` 可切换，且 drift 分支每次只调用一次生成器。
3. TA-AE/CLC 的输入输出接口不因替换而改变。
4. smoke 训练 loss 有限，至少能观察到下降趋势，并保存可复现配置和结果。
5. 测试、脚本和限制说明均可由仓库内命令复跑。

论文级复现另行验收：

1. 加载官方 YODA checkpoint 和 SANA-Sprint。
2. 在 UVG/HEVC Class B/MCL-JCV 上完成同协议评估。
3. 报告 rate-distortion/perceptual 指标与论文对比。

## 7. 已知限制

- 公开 YODA 源码不包含训练代码，原论文训练损失无法从源码逐行核验。
- 本地未发现 YODA/SANA checkpoint，无法完成论文级权重复现。
- 当前 PyTorch 构建与 RTX 5060 的 `sm_120` 不匹配，CUDA kernel 可能无法运行；CPU smoke 可先验证数学和接口。
- Drifting 条件化到 YODA 的压缩潜变量属于适配研究，需要单独训练和消融。
- 8 GB 显存不足以按论文配置运行 1080p 全精度 YODA；真实实验需降低分辨率、冻结模块或使用更大显存。
- 熵编码扩展 `MLCodec_extensions_cpp` 尚未在本地环境构建，真实码流测试需先完成 C++ 扩展安装。

## 8. 执行顺序

1. 实现 PyTorch 漂移损失和 memory bank。
2. 实现条件一步漂移生成器。
3. 将 YODA 去噪逻辑抽象为可切换组件，保留原始接口。
4. 添加合成数据 smoke 脚本和单元测试。
5. 在 CPU 上跑通数学/接口测试，在可用 GPU 上记录兼容性结果。
6. 若提供官方 checkpoint，再执行真实视频子集复现与对比。

## 9. 本地执行记录

执行日期：2026-10-28。

已完成：

1. 将 Drifting 官方 JAX `drift_loss.py` 的公式移植为 PyTorch，实现多温度核注意力、正负力、逐温度归一化、stop-gradient 和 MSE 目标。
2. 实现 CPU 友好的条件 memory bank、单次前向的 `ConditionalDriftGenerator` 和 `ConditionalDriftTrainer`。
3. 实现 `YodaHybridCodec`，保留 `forward/compress/decompress` 接口，并通过 `denoiser="drift"` 或 `denoiser="original"` 切换生成器。
4. 修正原 SANA checkpoint 的加载路径：`state_dict_transformer` 现在直接加载到内部 transformer；drift 分支不要求 prompt embedding 文件。
5. 按上游 `src/YODA.py` 复刻 SANA 的 `conv_in` 替换逻辑，保证 original 分支的模型结构与 YODA 原始推理代码一致。
6. 建立 24 项 `unittest`，覆盖漂移公式、梯度、memory bank、单次 NFE、训练下降、YODA 编解码接口、单步调度、SANA 输入卷积和原始 transformer 权重加载。
7. 在合成的 8 帧低分辨率潜变量序列上完成 100 步 CPU smoke 训练，保存 loss、配置、环境和预览图。

实测命令：

```powershell
D:\Users\YongZhao\anaconda3\envs\pytorch\python.exe -m unittest discover -s tests -v
D:\Users\YongZhao\anaconda3\envs\pytorch\python.exe scripts\train_drift_smoke.py --steps 100 --batch-size 4 --frames 8 --latent-size 8 --latent-channels 4 --context-channels 8 4 --hidden-channels 16 --depth 1 --device cpu
```

实测结果：

- 单元测试：24/24 通过。
- smoke 训练：100 步完成，平均 loss 从 `7.3000` 降至 `6.8499`，耗时约 `1.28s`（CPU）。
- 输出：`outputs/drift_smoke/metrics.json`、`outputs/drift_smoke/latent_preview.png` 与 `outputs/drift_smoke/generator.pt`。
- CUDA：RTX 5060 Laptop 的计算能力为 `sm_120`，当前 PyTorch 2.8.0+cu126 仅编译到 `sm_90`；实际 CUDA kernel 启动报 `no kernel image is available for execution on the device`，因此本轮使用 CPU。

尚未完成：

- 未找到 YODA/SANA checkpoint，无法加载论文权重或复现论文 PSNR、LPIPS、DISTS、FID、bpp。
- 未安装 `diffusers`、`peft`、`jax`、`yaml`，未构建 `MLCodec_extensions_cpp`，因此真实 compress/decompress 码流路径未执行。
- 当前 smoke 使用的是合成潜变量和伪 TA-AE 多尺度上下文，用于验证算法、接口和训练链路，不是真实视频数据集结果。
